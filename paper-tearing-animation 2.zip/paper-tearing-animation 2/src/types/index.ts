export interface BurnParameters {
  // Scroll & physics
  scrollSensitivity: number; // 0.2 to 3.0 (default ~1.0)
  scrollSmoothing: number; // 0.05 to 0.3 (damping factor)
  burnProgress: number; // 0.0 to 1.0
  surfaceScroll: number; // 0.0 to 1.0 (how much lower surface scrolls with tear, matches video)
  upperScroll: number; // 0.0 to 1.0 (how far the upper artwork travels up with the tear)

  // Torn paper ridge mechanics
  burnWidth: number; // 0.01 to 0.08 (thickness of the white deckle edge)
  ridgeSize: number; // 0.005 to 0.06 (height / depth of small ridges - very small by default)
  ridgeSpread: number; // 0.4 to 4.0 (spreadness / horizontal spacing of ridges)
  rashSpread: number; // 0.0 to 0.08 (how far fiber rashes scatter above the edge)
  rashDensity: number; // 0.0 to 1.0 (how many fiber rashes appear)
  edgeVariation: number; // 0.0 to 1.0 (how much lip width and rashes vary along the tear)
  rashInner: number; // 0.0 to 0.08 (how far rashes spread inward into the lip and lower page)
  tearRoughness: number; // 1.0 to 6.0 (frequency of fine paper grain)
  tearAmplitude: number; // 0.02 to 0.20 (overall tear wave amplitude)

  // Color parameters
  burnColor: string; // e.g. '#ffffff'
  ashColor: string; // e.g. '#e0ded8'
  fiberColor: string; // e.g. '#ffffff' (torn paper pulp)
  colorPreset: string;

  // Auto small movement at edge
  autoEdgeMovement: boolean; // toggle auto movement
  edgeMovementIntensity: number; // 0.0 to 3.0 (subtle edge simmer)
  edgeSpeed: number; // 0.2 to 3.0 (speed of edge simmer)
  heatDisplacement: number; // 0.0 to 1.0

  // Optional legacy fields for backward compatibility
  charIntensity: number;
  glowIntensity: number;
  enableParticles: boolean;
  particleDensity: number;
}

export interface Chapter {
  id: string;
  romanNumeral: string;
  title: string;
  subheading: string;
  quoteHighlight: string;
  quoteRest: string;
  description: string;
  bgArtworkUrl: string;
  badge: string;
}

export interface PageLayer {
  type: 'preset' | 'upload';
  title: string;
  imageUrl: string;
  subtitle?: string;
  sourceName?: string;
}
