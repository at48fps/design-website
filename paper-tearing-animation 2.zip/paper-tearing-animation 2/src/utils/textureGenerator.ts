import * as THREE from 'three';
import { Chapter } from '../types';

export interface RenderUpperOptions {
  chapter: Chapter;
  customImageUrl?: string | null;
}

export interface RenderBelowOptions {
  customImageUrl?: string | null;
  defaultDashboardUrl?: string;
}

// Helper to load an HTMLImageElement asynchronously
export const loadImage = (src: string): Promise<HTMLImageElement> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    if (!src.startsWith('data:')) {
      img.crossOrigin = 'anonymous';
    }
    img.onload = () => resolve(img);
    img.onerror = (err) => {
      console.error('Failed to load image:', src.slice(0, 80), err);
      reject(err);
    };
    img.src = src;
  });
};

/**
 * Creates the Upper Page Texture without any overlaid text.
 * Renders pure artwork or uploaded image with crisp pixel ratio.
 */
export async function createUpperPageTexture(
  options: RenderUpperOptions
): Promise<THREE.CanvasTexture> {
  const bgUrl = options.customImageUrl || options.chapter.bgArtworkUrl;
  
  try {
    const img = await loadImage(bgUrl);
    const canvas = document.createElement('canvas');
    canvas.width = img.naturalWidth || 1920;
    canvas.height = img.naturalHeight || 1080;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('2D context failed');

    // Draw pristine image - NO TEXT OVERLAY
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.generateMipmaps = false;
    texture.needsUpdate = true;
    return texture;
  } catch (err) {
    console.warn('Fallback to gradient for upper texture', err);
    const canvas = document.createElement('canvas');
    canvas.width = 1920;
    canvas.height = 1080;
    const ctx = canvas.getContext('2d')!;
    const grad = ctx.createLinearGradient(0, 0, 1920, 1080);
    grad.addColorStop(0, '#1c1224');
    grad.addColorStop(1, '#0b0b0e');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 1920, 1080);
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.needsUpdate = true;
    return texture;
  }
}

/**
 * Creates the Below Page Texture without any overlaid text.
 * Renders pure dashboard or uploaded image with crisp pixel ratio.
 */
export async function createBelowPageTexture(
  options: RenderBelowOptions
): Promise<THREE.CanvasTexture> {
  const bgUrl =
    options.customImageUrl ||
    options.defaultDashboardUrl ||
    '/src/assets/images/sidekick_pulse_dashboard_1793789347093.jpg';

  try {
    const img = await loadImage(bgUrl);
    const canvas = document.createElement('canvas');
    canvas.width = img.naturalWidth || 1920;
    canvas.height = img.naturalHeight || 1080;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('2D context failed');

    // Draw pristine image - NO TEXT OVERLAY
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.generateMipmaps = false;
    texture.needsUpdate = true;
    return texture;
  } catch (err) {
    console.warn('Fallback to paper cream for lower texture', err);
    const canvas = document.createElement('canvas');
    canvas.width = 1920;
    canvas.height = 1080;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#ede8dd';
    ctx.fillRect(0, 0, 1920, 1080);
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.needsUpdate = true;
    return texture;
  }
}
