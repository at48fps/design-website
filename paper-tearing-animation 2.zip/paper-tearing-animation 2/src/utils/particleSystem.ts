/**
 * Ember Particle System for the Burning Paper Transition
 */

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  life: number;
  maxLife: number;
  color: string;
  alpha: number;
  wobbleSpeed: number;
  wobbleAmp: number;
}

export class EmberParticleSystem {
  private particles: Particle[] = [];
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D | null;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
  }

  public resize(width: number, height: number) {
    this.canvas.width = width;
    this.canvas.height = height;
  }

  public emit(
    count: number,
    burnNormalizedY: number, // 0.0 at top to 1.0 at bottom
    burnColor: string,
    edgeRoughnessNoise: (xNorm: number) => number
  ) {
    if (burnNormalizedY <= 0.02 || burnNormalizedY >= 0.98) return;

    const width = this.canvas.width;
    const height = this.canvas.height;
    const baseScreenY = burnNormalizedY * height;

    for (let i = 0; i < count; i++) {
      const xNorm = Math.random();
      const x = xNorm * width;
      const roughnessOffset = edgeRoughnessNoise(xNorm) * (height * 0.08);
      const y = baseScreenY + roughnessOffset + (Math.random() - 0.5) * 15;

      const maxLife = 40 + Math.random() * 60;
      this.particles.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 1.5,
        vy: -(1.2 + Math.random() * 2.5), // float upwards
        size: 1.2 + Math.random() * 2.8,
        life: 0,
        maxLife,
        color: Math.random() > 0.4 ? burnColor : '#ffffff',
        alpha: 0.9,
        wobbleSpeed: 2 + Math.random() * 4,
        wobbleAmp: 0.5 + Math.random() * 1.5,
      });
    }

    // Cap particles for peak 60fps performance
    if (this.particles.length > 250) {
      this.particles.splice(0, this.particles.length - 250);
    }
  }

  public updateAndDraw(time: number) {
    if (!this.ctx) return;
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life++;

      if (p.life >= p.maxLife) {
        this.particles.splice(i, 1);
        continue;
      }

      const progress = p.life / p.maxLife;
      p.x += p.vx + Math.sin(time * p.wobbleSpeed + i) * p.wobbleAmp;
      p.y += p.vy;
      p.alpha = Math.max(0, 1.0 - Math.pow(progress, 1.5));
      p.size = Math.max(0.2, p.size * 0.99);

      // Draw glowing ember
      this.ctx.save();
      this.ctx.globalAlpha = p.alpha;
      this.ctx.fillStyle = p.color;
      this.ctx.shadowColor = p.color;
      this.ctx.shadowBlur = 8;

      this.ctx.beginPath();
      this.ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      this.ctx.fill();
      this.ctx.restore();
    }
  }

  public clear() {
    this.particles = [];
    if (this.ctx) {
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
  }
}
