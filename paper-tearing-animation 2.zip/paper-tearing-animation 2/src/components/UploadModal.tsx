import React, { useState, useRef, useEffect } from 'react';
import { X, Upload, Check } from 'lucide-react';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetLayer: 'upper' | 'below';
  onImageSelected: (dataUrl: string) => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  targetLayer,
  onImageSelected,
}) => {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Reset preview when modal opens or target layer changes
  useEffect(() => {
    if (isOpen) {
      setPreviewUrl(null);
      setFileName('');
      setIsDragging(false);
    }
  }, [isOpen, targetLayer]);

  if (!isOpen) return null;

  const processFile = (file: File) => {
    const isImage = file.type.startsWith('image/') || /\.(jpe?g|png|webp|gif|svg|avif|bmp)$/i.test(file.name);
    if (!isImage) {
      alert('Please select an image file (PNG, JPG, WEBP, or SVG).');
      return;
    }
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        setPreviewUrl(result);
      }
    };
    reader.onerror = (err) => {
      console.error('FileReader error:', err);
      alert('Failed to read image file.');
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleConfirm = () => {
    if (previewUrl) {
      onImageSelected(previewUrl);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-lg bg-neutral-900 border border-white/20 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 bg-neutral-950">
          <div>
            <h3 className="text-sm font-semibold text-white">
              Upload Custom {targetLayer === 'upper' ? 'Upper Image (Burn Layer)' : 'Below Image (Revealed Layer)'}
            </h3>
            <p className="text-xs text-white/50">
              {targetLayer === 'upper'
                ? 'This image will be the top page that burns away on scroll.'
                : 'This image will be revealed underneath the burning edge.'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileChange}
          />

          {previewUrl ? (
            <div className="space-y-3">
              <div className="relative aspect-video rounded-xl overflow-hidden border border-white/20 bg-black/50 flex items-center justify-center">
                <img
                  src={previewUrl}
                  alt="Upload preview"
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="flex items-center justify-between text-xs text-white/60">
                <span className="truncate max-w-[240px] text-white/90 font-mono">{fileName}</span>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="text-amber-400 hover:underline"
                >
                  Change Image
                </button>
              </div>
            </div>
          ) : (
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={onDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-colors ${
                isDragging
                  ? 'border-amber-400 bg-amber-500/10'
                  : 'border-white/20 hover:border-white/40 bg-white/5 hover:bg-white/10'
              }`}
            >
              <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center text-amber-400 mb-3">
                <Upload className="w-6 h-6" />
              </div>
              <p className="text-sm font-medium text-white mb-1">
                Click to browse or drag and drop image
              </p>
              <p className="text-xs text-white/50">
                Supports PNG, JPG, WEBP, or SVG
              </p>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 px-5 py-3 border-t border-white/10 bg-neutral-950">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-xs font-medium text-white/70 hover:text-white transition-colors"
          >
            Cancel
          </button>
          <button
            disabled={!previewUrl}
            onClick={handleConfirm}
            className="flex items-center gap-1.5 px-5 py-2 rounded-lg text-xs font-semibold text-black bg-amber-500 hover:bg-amber-400 disabled:opacity-40 disabled:cursor-not-allowed transition-all shadow-md"
          >
            <Check className="w-4 h-4" />
            <span>Apply to {targetLayer === 'upper' ? 'Upper Layer' : 'Below Layer'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
