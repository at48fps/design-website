import React, { useState, useRef } from 'react';
import { BurnParameters, Chapter } from '../types';
import { COLOR_PRESETS } from '../data/chapters';
import {
  Sliders,
  Scissors,
  Activity,
  Layers,
  Upload,
  ChevronDown,
  ChevronUp,
  Sparkles,
  RotateCcw,
  Palette,
  BookOpen,
  Save,
  Check,
} from 'lucide-react';

interface ParameterDockProps {
  parameters: BurnParameters;
  onChange: (newParams: Partial<BurnParameters>) => void;
  onReset: () => void;
  onSaveAsDefault: () => void;
  isSaved?: boolean;
  chapters: Chapter[];
  activeChapterId: string;
  onSelectChapter: (id: string) => void;
  onUploadUpperDirect: (file: File) => void;
  onUploadBelowDirect: (file: File) => void;
  hasCustomUpper: boolean;
  hasCustomBelow: boolean;
  onResetUpper: () => void;
  onResetBelow: () => void;
  isOpen: boolean;
  onToggleOpen: () => void;
}

type TabType = 'tear' | 'chapters' | 'physics' | 'movement' | 'color' | 'layers';

export const ParameterDock: React.FC<ParameterDockProps> = ({
  parameters,
  onChange,
  onReset,
  onSaveAsDefault,
  isSaved = false,
  chapters,
  activeChapterId,
  onSelectChapter,
  onUploadUpperDirect,
  onUploadBelowDirect,
  hasCustomUpper,
  hasCustomBelow,
  onResetUpper,
  onResetBelow,
  isOpen,
  onToggleOpen,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('tear');
  const upperFileInputRef = useRef<HTMLInputElement>(null);
  const belowFileInputRef = useRef<HTMLInputElement>(null);

  const handleUpperChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onUploadUpperDirect(e.target.files[0]);
      e.target.value = '';
    }
  };

  const handleBelowChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onUploadBelowDirect(e.target.files[0]);
      e.target.value = '';
    }
  };

  return (
    <div
      className={`fixed bottom-3 left-1/2 -translate-x-1/2 z-40 w-[96vw] max-w-4xl transition-all duration-300 pointer-events-auto ${
        isOpen ? 'translate-y-0 opacity-100' : 'translate-y-[calc(100%-42px)]'
      }`}
    >
      <input
        ref={upperFileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleUpperChange}
      />
      <input
        ref={belowFileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleBelowChange}
      />

      {/* Dock Top Handle / Toggle */}
      <div className="flex justify-center -mb-px">
        <button
          onClick={onToggleOpen}
          className="flex items-center gap-2 px-5 py-2 rounded-t-xl bg-black/90 hover:bg-black text-xs font-medium text-white/90 border-t border-x border-white/20 backdrop-blur-md shadow-2xl transition-all"
        >
          <Sliders className="w-3.5 h-3.5 text-amber-400" />
          <span>{isOpen ? 'Collapse Controls' : 'Torn Paper & Scroll Parameters'}</span>
          {isOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Main Glass Panel */}
      <div className="rounded-2xl bg-neutral-950/95 border border-white/15 backdrop-blur-xl shadow-2xl overflow-hidden p-4 sm:p-5">
        {/* Navigation Tabs */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4 gap-2 overflow-x-auto scrollbar-none">
          <div className="flex items-center gap-1.5 p-1 bg-white/5 rounded-lg">
            <button
              onClick={() => setActiveTab('tear')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                activeTab === 'tear'
                  ? 'bg-white text-black shadow-sm font-semibold'
                  : 'text-white/70 hover:text-white'
              }`}
            >
              <Scissors className="w-3.5 h-3.5" />
              <span>Torn Edge</span>
            </button>

            <button
              onClick={() => setActiveTab('chapters')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                activeTab === 'chapters'
                  ? 'bg-white text-black shadow-sm font-semibold'
                  : 'text-white/70 hover:text-white'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Upper Chapter</span>
            </button>

            <button
              onClick={() => setActiveTab('layers')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                activeTab === 'layers'
                  ? 'bg-white text-black shadow-sm font-semibold'
                  : 'text-white/70 hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Upload Custom Images</span>
            </button>

            <button
              onClick={() => setActiveTab('physics')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                activeTab === 'physics'
                  ? 'bg-white text-black shadow-sm font-semibold'
                  : 'text-white/70 hover:text-white'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Scroll Sensitivity</span>
            </button>

            <button
              onClick={() => setActiveTab('movement')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                activeTab === 'movement'
                  ? 'bg-white text-black shadow-sm font-semibold'
                  : 'text-white/70 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Edge Movement</span>
            </button>

            <button
              onClick={() => setActiveTab('color')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                activeTab === 'color'
                  ? 'bg-white text-black shadow-sm font-semibold'
                  : 'text-white/70 hover:text-white'
              }`}
            >
              <Palette className="w-3.5 h-3.5" />
              <span>Paper Fiber Color</span>
            </button>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Save as Default Button */}
            <button
              onClick={onSaveAsDefault}
              title="Save current parameter settings as permanent default"
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all shadow-sm ${
                isSaved
                  ? 'bg-emerald-500 text-black shadow-emerald-500/20'
                  : 'bg-white hover:bg-slate-200 text-black'
              }`}
            >
              {isSaved ? <Check className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
              <span>{isSaved ? 'Default Saved!' : 'Save as Default'}</span>
            </button>

            {/* Reset to Default Button */}
            <button
              onClick={onReset}
              title="Reset parameters to saved default"
              className="flex items-center gap-1 text-[11px] text-white/50 hover:text-white px-2 py-1.5 rounded-md hover:bg-white/5 transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              <span className="hidden sm:inline">Reset</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Authentic Torn Paper Deckle Edge */}
        {activeTab === 'tear' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            {/* Live Tear Progress Scrubber */}
            <div className="sm:col-span-2 lg:col-span-3 p-3 rounded-xl bg-white/5 border border-white/10 space-y-2">
              <div className="flex items-center justify-between text-white/90">
                <span className="font-medium flex items-center gap-2">
                  <Scissors className="w-4 h-4 text-amber-400" />
                  Tear Transition Progress (Live Scrubber)
                </span>
                <span className="font-mono text-amber-400 font-bold tabular-nums">
                  {Math.round(parameters.burnProgress * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.005"
                value={parameters.burnProgress}
                onChange={(e) => onChange({ burnProgress: parseFloat(e.target.value) })}
                className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer accent-white"
              />
              <div className="flex justify-between text-[10px] text-white/40">
                <span>0% (Upper Page)</span>
                <span>50% (Torn Paper Edge with Cast Shadow)</span>
                <span>100% (Below Page Revealed)</span>
              </div>
            </div>

            {/* 1. Ridge Size (Height - Reduced to Very Small) */}
            <div className="space-y-1.5 p-2.5 rounded-lg bg-white/5 border border-white/10">
              <div className="flex justify-between text-white/90">
                <span className="font-medium">Ridge Size (Height)</span>
                <span className="font-mono text-amber-400 font-bold tabular-nums">
                  {((parameters.ridgeSize ?? 0.015) * 1000).toFixed(1)}
                </span>
              </div>
              <input
                type="range"
                min="0.004"
                max="0.040"
                step="0.002"
                value={parameters.ridgeSize ?? 0.015}
                onChange={(e) => onChange({ ridgeSize: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="text-[10px] text-white/40">Very small subtle paper tooth matching video</div>
            </div>

            {/* 2. Ridge Spreadness (Horizontal Spacing / Density) */}
            <div className="space-y-1.5 p-2.5 rounded-lg bg-white/5 border border-white/10">
              <div className="flex justify-between text-white/90">
                <span className="font-medium">Ridge Spreadness (Spacing)</span>
                <span className="font-mono text-amber-400 font-bold tabular-nums">
                  {(parameters.ridgeSpread ?? 1.6).toFixed(1)}x
                </span>
              </div>
              <input
                type="range"
                min="0.4"
                max="3.5"
                step="0.1"
                value={parameters.ridgeSpread ?? 1.6}
                onChange={(e) => onChange({ ridgeSpread: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="text-[10px] text-white/40">Spread out vs densely packed tear ridges</div>
            </div>

            {/* 3. Surface Scroll Sync (Matching Reference Video) */}
            <div className="space-y-1.5 p-2.5 rounded-lg bg-white/5 border border-white/10">
              <div className="flex justify-between text-white/90">
                <span className="font-medium">Surface Scroll Sync</span>
                <span className="font-mono text-amber-400 font-bold tabular-nums">
                  {Math.round((parameters.surfaceScroll ?? 0.42) * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.0"
                max="0.80"
                step="0.02"
                value={parameters.surfaceScroll ?? 0.42}
                onChange={(e) => onChange({ surfaceScroll: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="text-[10px] text-white/40">Lower page scrolls upward with tear (exact video match)</div>
            </div>

            {/* 3b. Upper Artwork Scroll */}
            <div className="space-y-1.5 p-2.5 rounded-lg bg-white/5 border border-white/10">
              <div className="flex justify-between text-white/90">
                <span className="font-medium">Artwork Scroll Sync</span>
                <span className="font-mono text-amber-400 font-bold tabular-nums">
                  {Math.round((parameters.upperScroll ?? 0.85) * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.0"
                max="1.0"
                step="0.05"
                value={parameters.upperScroll ?? 0.85}
                onChange={(e) => onChange({ upperScroll: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="text-[10px] text-white/40">Upper artwork travels up with the tear while scrolling</div>
            </div>

            {/* 4. White Deckle Lip Width */}
            <div className="space-y-1.5 p-2.5 rounded-lg bg-white/5 border border-white/10">
              <div className="flex justify-between text-white/90">
                <span className="font-medium">White Deckle Lip Width</span>
                <span className="font-mono text-amber-400 font-bold tabular-nums">
                  {(parameters.burnWidth * 100).toFixed(1)}%
                </span>
              </div>
              <input
                type="range"
                min="0.010"
                max="0.050"
                step="0.002"
                value={parameters.burnWidth}
                onChange={(e) => onChange({ burnWidth: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="text-[10px] text-white/40">Exposed raw white paper core border</div>
            </div>

            {/* 5. Fiber Rash Spread & Density */}
            <div className="space-y-1.5 p-2.5 rounded-lg bg-white/5 border border-white/10">
              <div className="flex justify-between text-white/90">
                <span className="font-medium">Outer Rash Spread</span>
                <span className="font-mono text-amber-400 font-bold tabular-nums">
                  {((parameters.rashSpread ?? 0.03) * 100).toFixed(1) + '%'}
                </span>
              </div>
              <input
                type="range"
                min="0.0"
                max="0.080"
                step="0.002"
                value={parameters.rashSpread ?? 0.03}
                onChange={(e) => onChange({ rashSpread: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="text-[10px] text-white/40">How far fiber rashes scatter above the torn edge</div>
            </div>

            <div className="space-y-1.5 p-2.5 rounded-lg bg-white/5 border border-white/10">
              <div className="flex justify-between text-white/90">
                <span className="font-medium">Rash Density</span>
                <span className="font-mono text-amber-400 font-bold tabular-nums">
                  {Math.round((parameters.rashDensity ?? 0.6) * 100) + '%'}
                </span>
              </div>
              <input
                type="range"
                min="0.0"
                max="1.0"
                step="0.05"
                value={parameters.rashDensity ?? 0.6}
                onChange={(e) => onChange({ rashDensity: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="text-[10px] text-white/40">Sparse specks vs dense fibrous rash</div>
            </div>
            <div className="space-y-1.5 p-2.5 rounded-lg bg-white/5 border border-white/10">
              <div className="flex justify-between text-white/90">
                <span className="font-medium">Inner Rash Spread</span>
                <span className="font-mono text-amber-400 font-bold tabular-nums">
                  {((parameters.rashInner ?? 0.02) * 100).toFixed(1) + '%'}
                </span>
              </div>
              <input
                type="range"
                min="0.0"
                max="0.080"
                step="0.002"
                value={parameters.rashInner ?? 0.02}
                onChange={(e) => onChange({ rashInner: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="text-[10px] text-white/40">How far rashes spread inward into the white lip and revealed page</div>
            </div>
            <div className="space-y-1.5 p-2.5 rounded-lg bg-white/5 border border-white/10">
              <div className="flex justify-between text-white/90">
                <span className="font-medium">Edge Variation</span>
                <span className="font-mono text-amber-400 font-bold tabular-nums">
                  {Math.round((parameters.edgeVariation ?? 0.7) * 100) + '%'}
                </span>
              </div>
              <input
                type="range"
                min="0.0"
                max="1.0"
                step="0.05"
                value={parameters.edgeVariation ?? 0.7}
                onChange={(e) => onChange({ edgeVariation: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="text-[10px] text-white/40">Randomness of lip width and rashes along the tear (0 = uniform)</div>
            </div>
          </div>
        )}

        {/* Tab 2: Upper Chapter Selector */}
        {activeTab === 'chapters' && (
          <div className="space-y-2 text-xs">
            <div className="text-white/60 mb-2">
              Select artwork chapter for the upper page:
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
              {chapters.map((ch) => {
                const isSelected = ch.id === activeChapterId && !hasCustomUpper;
                return (
                  <button
                    key={ch.id}
                    onClick={() => {
                      onSelectChapter(ch.id);
                      if (hasCustomUpper) onResetUpper();
                    }}
                    className={`flex items-center gap-2 p-2.5 rounded-lg border text-left transition-all ${
                      isSelected
                        ? 'bg-white/20 border-white text-white font-medium'
                        : 'bg-white/5 border-white/10 text-white/70 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <span className="font-mono text-[10px] text-amber-400">
                      {ch.romanNumeral}
                    </span>
                    <span className="truncate">{ch.title}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 3: Custom Layer Uploads */}
        {activeTab === 'layers' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            {/* Upper Page Layer */}
            <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-white font-medium">Upper Page (The Torn Layer)</div>
                  <div className="text-[11px] text-white/50">
                    {hasCustomUpper ? 'Custom Image Active' : 'Chapter Artwork'}
                  </div>
                </div>
                {hasCustomUpper && (
                  <button
                    onClick={onResetUpper}
                    className="text-[11px] text-amber-400 hover:underline"
                  >
                    Reset
                  </button>
                )}
              </div>

              <button
                onClick={() => upperFileInputRef.current?.click()}
                className="w-full py-3 px-4 rounded-lg bg-white/10 hover:bg-white/15 border border-dashed border-white/20 hover:border-white/40 flex items-center justify-center gap-2 text-white/90 font-medium transition-colors"
              >
                <Upload className="w-4 h-4 text-amber-400" />
                <span>Upload Custom Upper Image (PNG / JPG)</span>
              </button>
            </div>

            {/* Below Page Layer */}
            <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-white font-medium">Below Page (Revealed Layer)</div>
                  <div className="text-[11px] text-white/50">
                    {hasCustomBelow ? 'Custom Image Active' : 'Default Paper Dashboard'}
                  </div>
                </div>
                {hasCustomBelow && (
                  <button
                    onClick={onResetBelow}
                    className="text-[11px] text-purple-400 hover:underline"
                  >
                    Reset
                  </button>
                )}
              </div>

              <button
                onClick={() => belowFileInputRef.current?.click()}
                className="w-full py-3 px-4 rounded-lg bg-white/10 hover:bg-white/15 border border-dashed border-white/20 hover:border-white/40 flex items-center justify-center gap-2 text-white/90 font-medium transition-colors"
              >
                <Upload className="w-4 h-4 text-purple-400" />
                <span>Upload Custom Below Image (PNG / JPG)</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 4: Scroll Sensitivity & Physics */}
        {activeTab === 'physics' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="space-y-2 p-3.5 rounded-xl bg-white/5 border border-white/10">
              <div className="flex justify-between text-white/90">
                <span className="font-medium">Scroll Sensitivity Multiplier</span>
                <span className="font-mono text-amber-400 font-bold tabular-nums">
                  {parameters.scrollSensitivity.toFixed(2)}x
                </span>
              </div>
              <input
                type="range"
                min="0.2"
                max="3.0"
                step="0.05"
                value={parameters.scrollSensitivity}
                onChange={(e) => onChange({ scrollSensitivity: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-white"
              />
              <p className="text-[11px] text-white/50">
                Controls how much paper tear movement occurs per scroll wheel notch or touch drag.
              </p>
            </div>

            <div className="space-y-2 p-3.5 rounded-xl bg-white/5 border border-white/10">
              <div className="flex justify-between text-white/90">
                <span className="font-medium">Scroll Inertia & Smoothing</span>
                <span className="font-mono text-amber-400 font-bold tabular-nums">
                  {(parameters.scrollSmoothing * 100).toFixed(0)}%
                </span>
              </div>
              <input
                type="range"
                min="0.02"
                max="0.30"
                step="0.01"
                value={parameters.scrollSmoothing}
                onChange={(e) => onChange({ scrollSmoothing: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-white"
              />
              <p className="text-[11px] text-white/50">
                Applies physical paper inertia easing when scrolling stops.
              </p>
            </div>
          </div>
        )}

        {/* Tab 5: Auto Small Movement at Edge */}
        {activeTab === 'movement' && (
          <div className="space-y-4 text-xs">
            <div className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/10">
              <div>
                <div className="text-white font-medium flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  Continuous Idle Flutter
                </div>
                <div className="text-[11px] text-white/50">
                  By default, edge moves dynamically only when scrolling (as in the video). Toggle on for continuous idle fluttering.
                </div>
              </div>
              <button
                onClick={() => onChange({ autoEdgeMovement: !parameters.autoEdgeMovement })}
                className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                  parameters.autoEdgeMovement ? 'bg-white' : 'bg-white/20'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    parameters.autoEdgeMovement ? 'translate-x-5 bg-black' : 'translate-x-0 bg-white'
                  }`}
                />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <div className="flex justify-between text-white/80">
                  <span>Edge Flutter Amplitude</span>
                  <span className="font-mono text-white/60 tabular-nums">
                    {parameters.edgeMovementIntensity.toFixed(1)}x
                  </span>
                </div>
                <input
                  type="range"
                  min="0.0"
                  max="3.0"
                  step="0.1"
                  disabled={!parameters.autoEdgeMovement}
                  value={parameters.edgeMovementIntensity}
                  onChange={(e) => onChange({ edgeMovementIntensity: parseFloat(e.target.value) })}
                  className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-white disabled:opacity-30"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-white/80">
                  <span>Flutter Oscillation Speed</span>
                  <span className="font-mono text-white/60 tabular-nums">
                    {parameters.edgeSpeed.toFixed(1)}x
                  </span>
                </div>
                <input
                  type="range"
                  min="0.2"
                  max="3.0"
                  step="0.1"
                  disabled={!parameters.autoEdgeMovement}
                  value={parameters.edgeSpeed}
                  onChange={(e) => onChange({ edgeSpeed: parseFloat(e.target.value) })}
                  className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-white disabled:opacity-30"
                />
              </div>
            </div>
          </div>
        )}

        {/* Tab 6: Paper Fiber Color */}
        {activeTab === 'color' && (
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/10">
                <input
                  type="color"
                  value={parameters.fiberColor}
                  onChange={(e) => onChange({ fiberColor: e.target.value })}
                  className="w-9 h-9 rounded border-0 bg-transparent cursor-pointer"
                />
                <div>
                  <div className="text-white font-medium">Torn Paper Pulp Color</div>
                  <div className="text-[11px] text-white/50">
                    Default: Pure Bleached Pulp (#ffffff)
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {[
                  { name: 'Pure White (Screenshot)', color: '#ffffff' },
                  { name: 'Warm Parchment', color: '#f5f0e6' },
                  { name: 'Cream Deckle', color: '#ede7d8' },
                ].map((preset) => (
                  <button
                    key={preset.color}
                    onClick={() => onChange({ fiberColor: preset.color })}
                    className="flex-1 p-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-center transition-all"
                  >
                    <div
                      className="w-4 h-4 rounded-full mx-auto mb-1 border border-white/30"
                      style={{ backgroundColor: preset.color }}
                    />
                    <span className="text-[10px] text-white/80">{preset.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
