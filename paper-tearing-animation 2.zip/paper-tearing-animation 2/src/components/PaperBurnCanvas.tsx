import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { BurnParameters } from '../types';
import { vertexShader, fragmentShader } from '../shaders/burnShader';
import { EmberParticleSystem } from '../utils/particleSystem';

interface PaperBurnCanvasProps {
  upperTexture: THREE.CanvasTexture | THREE.Texture | null;
  belowTexture: THREE.CanvasTexture | THREE.Texture | null;
  parameters: BurnParameters;
  onProgressChange: (newProgress: number) => void;
}

export const PaperBurnCanvas: React.FC<PaperBurnCanvasProps> = ({
  upperTexture,
  belowTexture,
  parameters,
  onProgressChange,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const particleCanvasRef = useRef<HTMLCanvasElement>(null);
  const particleSystemRef = useRef<EmberParticleSystem | null>(null);
  const materialRef = useRef<THREE.ShaderMaterial | null>(null);

  // Keep latest textures in refs to avoid stale closures
  const upperTextureRef = useRef<THREE.CanvasTexture | THREE.Texture | null>(upperTexture);
  upperTextureRef.current = upperTexture;

  const belowTextureRef = useRef<THREE.CanvasTexture | THREE.Texture | null>(belowTexture);
  belowTextureRef.current = belowTexture;

  // Keep latest parameters in ref for animation loop
  const paramsRef = useRef(parameters);
  paramsRef.current = parameters;

  const onProgressChangeRef = useRef(onProgressChange);
  onProgressChangeRef.current = onProgressChange;

  // Progress smoothing state
  const targetProgressRef = useRef(parameters.burnProgress);
  const currentProgressRef = useRef(parameters.burnProgress);
  const scrollVelocityRef = useRef(0);

  // Sync external scrub slider changes
  useEffect(() => {
    targetProgressRef.current = parameters.burnProgress;
  }, [parameters.burnProgress]);

  // Immediately update shader uniform when upperTexture changes
  useEffect(() => {
    if (materialRef.current && upperTexture) {
      materialRef.current.uniforms.u_textureUpper.value = upperTexture;
      upperTexture.needsUpdate = true;
      materialRef.current.needsUpdate = true;
    }
  }, [upperTexture]);

  // Immediately update shader uniform when belowTexture changes
  useEffect(() => {
    if (materialRef.current && belowTexture) {
      materialRef.current.uniforms.u_textureLower.value = belowTexture;
      belowTexture.needsUpdate = true;
      materialRef.current.needsUpdate = true;
    }
  }, [belowTexture]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Detect software GL
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    // Setup Three.js Renderer
    const renderer = new THREE.WebGLRenderer({
      powerPreference: 'high-performance',
      antialias: !isSoftwareGl,
      alpha: false,
    });
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(renderer.domElement);

    // Setup Particle System
    if (particleCanvasRef.current) {
      particleSystemRef.current = new EmberParticleSystem(particleCanvasRef.current);
      particleSystemRef.current.resize(width, height);
    }

    // Setup 2D Scene & Orthographic Camera
    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

    // Default 1x1 placeholder texture
    const placeholderTexture = new THREE.DataTexture(
      new Uint8Array([20, 20, 24, 255]),
      1,
      1,
      THREE.RGBAFormat
    );
    placeholderTexture.needsUpdate = true;

    // Create shader material uniforms
    const uniforms = {
      u_textureUpper: { value: upperTextureRef.current || placeholderTexture },
      u_textureLower: { value: belowTextureRef.current || placeholderTexture },
      u_progress: { value: parameters.burnProgress },
      u_time: { value: 0 },
      u_resolution: { value: new THREE.Vector2(width, height) },
      u_burnWidth: { value: parameters.burnWidth },
      u_ridgeSize: { value: parameters.ridgeSize ?? 0.012 },
      u_ridgeSpread: { value: parameters.ridgeSpread ?? 1.5 },
      u_surfaceScroll: { value: parameters.surfaceScroll ?? 0.45 },
      u_upperScroll: { value: parameters.upperScroll ?? 0.85 },
      u_tearAmplitude: { value: parameters.tearAmplitude ?? 0.045 },
      u_rashSpread: { value: parameters.rashSpread ?? 0.03 },
      u_rashDensity: { value: parameters.rashDensity ?? 0.6 },
      u_rashInner: { value: parameters.rashInner ?? 0.02 },
      u_edgeVariation: { value: parameters.edgeVariation ?? 0.7 },
      u_tearRoughness: { value: parameters.tearRoughness },
      u_autoEdgeMovement: { value: parameters.autoEdgeMovement ? 1.0 : 0.0 },
      u_edgeMovementIntensity: { value: parameters.edgeMovementIntensity },
      u_edgeSpeed: { value: parameters.edgeSpeed },
      u_scrollVelocity: { value: 0.0 },
      u_fiberColor: { value: new THREE.Color(parameters.fiberColor || '#ffffff') },
    };

    const material = new THREE.ShaderMaterial({
      vertexShader,
      fragmentShader,
      uniforms,
      depthTest: false,
      depthWrite: false,
    });

    materialRef.current = material;

    const geometry = new THREE.PlaneGeometry(2, 2);
    const quad = new THREE.Mesh(geometry, material);
    scene.add(quad);

    // --- RESPONSIVE SCROLL & INTERACTION ENGINE ---
    // 1. Wheel Listener on WINDOW (Captures all scroll gestures anywhere in the viewport)
    const handleWheel = (e: WheelEvent) => {
      // Don't intercept scroll if user is scrolling inside an explicit scrollable container (e.g. upload modal)
      const target = e.target as HTMLElement | null;
      if (target && target.closest('.no-canvas-scroll')) {
        return;
      }
      e.preventDefault();

      let delta = e.deltaY;
      if (e.deltaMode === 1) {
        // Line delta (Firefox / standard mouse wheel)
        delta *= 34;
      } else if (e.deltaMode === 2) {
        // Page delta
        delta *= window.innerHeight;
      }

      const p = paramsRef.current;
      // Normalizes scroll so a comfortable scroll gesture advances the paper tear naturally
      // Matches the responsive feel of the Shopify Editions website
      const scrollScale = 1.0 / (window.innerHeight * 0.95);
      const progressDelta = delta * scrollScale * p.scrollSensitivity;

      // Dynamic velocity impulse (triggers subtle paper flex while scrolling)
      scrollVelocityRef.current = Math.min(
        scrollVelocityRef.current + Math.abs(progressDelta) * 14.0,
        3.5
      );

      const nextProgress = Math.min(Math.max(targetProgressRef.current + progressDelta, 0.0), 1.0);
      targetProgressRef.current = nextProgress;
      onProgressChangeRef.current(nextProgress);
    };

    // 2. Keyboard Navigation (Arrows, PageUp/Down, Space, Home/End)
    const handleKeyDown = (e: KeyboardEvent) => {
      const activeEl = document.activeElement;
      if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) {
        return;
      }

      if (['ArrowDown', 'ArrowUp', 'PageDown', 'PageUp', ' ', 'Home', 'End'].includes(e.key)) {
        e.preventDefault();
        let step = 0;
        if (e.key === 'ArrowDown') step = 0.04;
        else if (e.key === 'ArrowUp') step = -0.04;
        else if (e.key === 'PageDown' || e.key === ' ') step = 0.18;
        else if (e.key === 'PageUp') step = -0.18;
        else if (e.key === 'Home') {
          targetProgressRef.current = 0.0;
          onProgressChangeRef.current(0.0);
          return;
        } else if (e.key === 'End') {
          targetProgressRef.current = 1.0;
          onProgressChangeRef.current(1.0);
          return;
        }

        const p = paramsRef.current;
        const progressDelta = step * p.scrollSensitivity;
        scrollVelocityRef.current = Math.min(
          scrollVelocityRef.current + Math.abs(progressDelta) * 14.0,
          3.5
        );
        const next = Math.min(Math.max(targetProgressRef.current + progressDelta, 0.0), 1.0);
        targetProgressRef.current = next;
        onProgressChangeRef.current(next);
      }
    };

    // 3. Touch Dragging on Mobile / Touchpads
    let isTouching = false;
    let touchStartY = 0;

    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        isTouching = true;
        touchStartY = e.touches[0].clientY;
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!isTouching || e.touches.length === 0) return;
      const touchY = e.touches[0].clientY;
      const deltaY = touchStartY - touchY; // Positive when swiping up (scrolling down)
      touchStartY = touchY;

      const p = paramsRef.current;
      const progressDelta = (deltaY / (window.innerHeight * 0.85)) * p.scrollSensitivity;

      scrollVelocityRef.current = Math.min(
        scrollVelocityRef.current + Math.abs(progressDelta) * 14.0,
        3.5
      );

      const nextProgress = Math.min(Math.max(targetProgressRef.current + progressDelta, 0.0), 1.0);
      targetProgressRef.current = nextProgress;
      onProgressChangeRef.current(nextProgress);
    };

    const handleTouchEnd = () => {
      isTouching = false;
    };

    // 4. Mouse Drag on Canvas
    let isMouseDown = false;
    let lastMouseY = 0;

    const handleMouseDown = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.closest('button') || target.closest('input') || target.closest('header')) return;
      isMouseDown = true;
      lastMouseY = e.clientY;
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!isMouseDown) return;
      const deltaY = lastMouseY - e.clientY;
      lastMouseY = e.clientY;

      const p = paramsRef.current;
      const progressDelta = (deltaY / (window.innerHeight * 0.85)) * p.scrollSensitivity;

      scrollVelocityRef.current = Math.min(
        scrollVelocityRef.current + Math.abs(progressDelta) * 14.0,
        3.5
      );

      const nextProgress = Math.min(Math.max(targetProgressRef.current + progressDelta, 0.0), 1.0);
      targetProgressRef.current = nextProgress;
      onProgressChangeRef.current(nextProgress);
    };

    const handleMouseUp = () => {
      isMouseDown = false;
    };

    // Attach listeners to window for universal, unhindered scroll control
    window.addEventListener('wheel', handleWheel, { passive: false });
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('touchstart', handleTouchStart, { passive: true });
    window.addEventListener('touchmove', handleTouchMove, { passive: true });
    window.addEventListener('touchend', handleTouchEnd);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);

    // Resize observer
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      renderer.setSize(w, h);
      uniforms.u_resolution.value.set(w, h);
      particleSystemRef.current?.resize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // Animation Render Loop
    let animationFrameId = 0;
    const clock = new THREE.Clock();

    const animate = () => {
      const delta = clock.getDelta();
      const elapsedTime = clock.getElapsedTime();

      // Exponential damping toward target progress
      const p = paramsRef.current;
      const smoothing = Math.min(Math.max(p.scrollSmoothing, 0.01), 0.4);
      const lerpFactor = 1.0 - Math.exp(-delta * (24.0 * (1.0 - smoothing * 1.6)));
      currentProgressRef.current += (targetProgressRef.current - currentProgressRef.current) * Math.min(lerpFactor, 1.0);

      // Smooth decay for dynamic scroll velocity
      scrollVelocityRef.current = THREE.MathUtils.lerp(
        scrollVelocityRef.current,
        0,
        Math.min(delta * 6.0, 1.0)
      );

      // Update uniforms
      uniforms.u_time.value = elapsedTime;
      uniforms.u_progress.value = currentProgressRef.current;
      uniforms.u_burnWidth.value = p.burnWidth;
      uniforms.u_ridgeSize.value = p.ridgeSize ?? 0.012;
      uniforms.u_ridgeSpread.value = p.ridgeSpread ?? 1.5;
      uniforms.u_surfaceScroll.value = p.surfaceScroll ?? 0.45;
      uniforms.u_upperScroll.value = p.upperScroll ?? 0.85;
      uniforms.u_tearAmplitude.value = p.tearAmplitude ?? 0.045;
      uniforms.u_rashSpread.value = p.rashSpread ?? 0.03;
      uniforms.u_rashDensity.value = p.rashDensity ?? 0.6;
      uniforms.u_rashInner.value = p.rashInner ?? 0.02;
      uniforms.u_edgeVariation.value = p.edgeVariation ?? 0.7;
      uniforms.u_tearRoughness.value = p.tearRoughness;
      uniforms.u_autoEdgeMovement.value = p.autoEdgeMovement ? 1.0 : 0.0;
      uniforms.u_edgeMovementIntensity.value = p.edgeMovementIntensity;
      uniforms.u_edgeSpeed.value = p.edgeSpeed;
      uniforms.u_scrollVelocity.value = scrollVelocityRef.current;
      uniforms.u_fiberColor.value.set(p.fiberColor || '#ffffff');

      // Check ref textures dynamically
      const curUpper = upperTextureRef.current;
      if (curUpper && uniforms.u_textureUpper.value !== curUpper) {
        uniforms.u_textureUpper.value = curUpper;
        curUpper.needsUpdate = true;
      }
      const curBelow = belowTextureRef.current;
      if (curBelow && uniforms.u_textureLower.value !== curBelow) {
        uniforms.u_textureLower.value = curBelow;
        curBelow.needsUpdate = true;
      }

      // Render WebGL
      renderer.render(scene, camera);

      // Particle update (if enabled)
      if (particleSystemRef.current) {
        if (p.enableParticles && currentProgressRef.current > 0.02 && currentProgressRef.current < 0.98) {
          const burnScreenY = 1.0 - currentProgressRef.current;
          const spawnCount = Math.floor(p.particleDensity * 0.08);
          particleSystemRef.current.emit(
            spawnCount,
            burnScreenY,
            p.burnColor,
            (xNorm) => Math.sin(xNorm * 12 + elapsedTime * 2) * 0.5
          );
        }
        particleSystemRef.current.updateAndDraw(elapsedTime);
      }

      animationFrameId = requestAnimationFrame(animate);
    };

    animationFrameId = requestAnimationFrame(animate);

    // Cleanup
    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('wheel', handleWheel);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);

      geometry.dispose();
      material.dispose();
      placeholderTexture.dispose();
      renderer.dispose();
      materialRef.current = null;
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div className="relative w-full h-screen overflow-hidden select-none cursor-ns-resize">
      {/* 3D WebGL Canvas Container */}
      <div ref={containerRef} className="absolute inset-0 w-full h-full" />

      {/* 2D Canvas for Ember Particles */}
      <canvas
        ref={particleCanvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none z-10"
      />
    </div>
  );
};
