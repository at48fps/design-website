import React from 'react';
import { Sliders, RotateCcw, Save, Check } from 'lucide-react';

interface TopNavProps {
  onToggleControls: () => void;
  controlsOpen: boolean;
  onResetProgress: () => void;
  onSaveAsDefault: () => void;
  isSaved?: boolean;
}

export const TopNav: React.FC<TopNavProps> = ({
  onToggleControls,
  controlsOpen,
  onResetProgress,
  onSaveAsDefault,
  isSaved = false,
}) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-40 h-14 flex items-center justify-between px-6 bg-gradient-to-b from-black/80 via-black/40 to-transparent pointer-events-auto">
      {/* Brand logo */}
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-sm bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-sm">
            <span className="text-[10px] font-bold text-black font-sans">S</span>
          </div>
          <span className="text-sm font-semibold tracking-tight text-white/90 whitespace-nowrap">
            Shopify Editions <span className="font-light text-white/50">Winter ’26</span>
          </span>
        </div>
      </div>

      {/* Action Controls */}
      <div className="flex items-center gap-2.5">
        {/* Reset Torn Page to 0% */}
        <button
          onClick={onResetProgress}
          title="Reset Torn Page (0%)"
          className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white/80 hover:text-white border border-white/10 transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        {/* Save as Default Button directly in Top Navigation */}
        <button
          onClick={onSaveAsDefault}
          title="Save current parameter settings as permanent default"
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all shadow-sm ${
            isSaved
              ? 'bg-emerald-500 text-black shadow-emerald-500/20'
              : 'bg-amber-400 hover:bg-amber-300 text-black'
          }`}
        >
          {isSaved ? <Check className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
          <span>{isSaved ? 'Default Saved!' : 'Save as Default'}</span>
        </button>

        {/* Parameter Controls Panel Toggle */}
        <button
          onClick={onToggleControls}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
            controlsOpen
              ? 'bg-white text-black shadow-md'
              : 'bg-white/10 hover:bg-white/20 text-white border border-white/15'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Parameters</span>
        </button>
      </div>
    </header>
  );
};
