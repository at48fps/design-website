import React, { useState } from 'react';
import { X, Play, Pause, RotateCcw } from 'lucide-react';

interface VideoCompareModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VideoCompareModal: React.FC<VideoCompareModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [playbackRate, setPlaybackRate] = useState(1);
  const videoRef = React.useRef<HTMLVideoElement>(null);

  if (!isOpen) return null;

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const setSpeed = (rate: number) => {
    setPlaybackRate(rate);
    if (videoRef.current) {
      videoRef.current.playbackRate = rate;
    }
  };

  const restartVideo = () => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-4xl bg-neutral-900 border border-white/20 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 bg-neutral-950">
          <div>
            <h3 className="text-sm font-semibold text-white">
              Shopify Editions Reference Recording
            </h3>
            <p className="text-xs text-white/50">
              Compare shader burn tear boundary and edge flutter against the actual recording
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Player Container */}
        <div className="relative bg-black aspect-video flex items-center justify-center overflow-hidden">
          <video
            ref={videoRef}
            src="/assets/aistudio/Screen_Recording_2026-11-04_at_4.13.33_PM_c699e23e.mov"
            autoPlay
            loop
            muted
            playsInline
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            className="w-full h-full object-contain"
          />
        </div>

        {/* Player Controls Bar */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-white/10 bg-neutral-950 text-xs">
          <div className="flex items-center gap-3">
            <button
              onClick={togglePlay}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-amber-500 hover:bg-amber-400 text-black font-semibold transition-colors"
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
              <span>{isPlaying ? 'Pause' : 'Play'}</span>
            </button>

            <button
              onClick={restartVideo}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-white/10 hover:bg-white/15 text-white/80 transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Replay</span>
            </button>
          </div>

          {/* Speed Presets */}
          <div className="flex items-center gap-1">
            <span className="text-white/40 mr-1 text-[11px]">Speed:</span>
            {[0.25, 0.5, 1, 2].map((rate) => (
              <button
                key={rate}
                onClick={() => setSpeed(rate)}
                className={`px-2 py-1 rounded text-[11px] font-mono transition-colors ${
                  playbackRate === rate
                    ? 'bg-white/20 text-white font-bold'
                    : 'text-white/50 hover:text-white'
                }`}
              >
                {rate}x
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
