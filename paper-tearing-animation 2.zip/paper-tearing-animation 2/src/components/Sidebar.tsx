import React, { useRef } from 'react';
import { Chapter } from '../types';
import { Upload, ChevronRight, Sparkles, RotateCcw } from 'lucide-react';

interface SidebarProps {
  chapters: Chapter[];
  activeChapterId: string;
  onSelectChapter: (chapterId: string) => void;
  onUploadUpperDirect: (file: File) => void;
  onUploadBelowDirect: (file: File) => void;
  hasCustomUpper: boolean;
  hasCustomBelow: boolean;
  onResetUpper: () => void;
  onResetBelow: () => void;
  isOpen: boolean;
  onToggleOpen: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  chapters,
  activeChapterId,
  onSelectChapter,
  onUploadUpperDirect,
  onUploadBelowDirect,
  hasCustomUpper,
  hasCustomBelow,
  onResetUpper,
  onResetBelow,
  isOpen,
  onToggleOpen,
}) => {
  const upperFileInputRef = useRef<HTMLInputElement>(null);
  const belowFileInputRef = useRef<HTMLInputElement>(null);

  const handleUpperChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onUploadUpperDirect(e.target.files[0]);
      e.target.value = ''; // allow re-uploading same filename
    }
  };

  const handleBelowChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onUploadBelowDirect(e.target.files[0]);
      e.target.value = '';
    }
  };

  return (
    <>
      {/* Hidden file inputs for instant one-click uploading */}
      <input
        ref={upperFileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleUpperChange}
      />
      <input
        ref={belowFileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleBelowChange}
      />

      {/* Mobile toggle button */}
      <button
        onClick={onToggleOpen}
        aria-label="Toggle Navigation Sidebar"
        className="fixed top-18 left-4 z-40 lg:hidden p-2.5 rounded-lg bg-black/60 backdrop-blur-md border border-white/10 text-white/90 hover:bg-black/80 transition-colors shadow-lg"
      >
        <span className="text-xs font-medium uppercase tracking-wider font-mono">
          {isOpen ? 'Close Nav' : 'Chapters'}
        </span>
      </button>

      {/* Main Sidebar Drawer */}
      <aside
        className={`fixed top-0 left-0 bottom-0 z-30 w-72 flex flex-col justify-between p-6 pt-20 transition-transform duration-300 ease-in-out pointer-events-auto bg-gradient-to-r from-black/85 via-black/60 to-transparent lg:bg-transparent ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Edition Header */}
        <div className="mb-4">
          <div className="text-[11px] font-medium tracking-[0.2em] text-white/50 uppercase font-sans mb-1">
            Shopify Editions · Winter ’26
          </div>
          <h2 className="text-2xl font-normal tracking-tight text-white font-editorial leading-tight">
            The<br />
            <span className="italic font-light">Renaissance</span><br />
            Edition
          </h2>
        </div>

        {/* Chapters Navigation List */}
        <nav className="flex-1 overflow-y-auto pr-2 -mr-2 space-y-1 py-1 text-sm select-none scrollbar-thin scrollbar-thumb-white/10">
          <div className="text-[10px] font-semibold uppercase tracking-widest text-white/40 mb-2 px-2">
            Chapters
          </div>
          {chapters.map((ch) => {
            const isActive = ch.id === activeChapterId && !hasCustomUpper;
            return (
              <button
                key={ch.id}
                onClick={() => {
                  onSelectChapter(ch.id);
                  if (window.innerWidth < 1024) onToggleOpen();
                }}
                className={`w-full group flex items-center justify-between px-2.5 py-1.5 rounded-md text-left transition-all ${
                  isActive
                    ? 'text-white font-medium bg-white/10 shadow-sm'
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                <span className="flex items-center gap-2 truncate">
                  <span
                    className={`text-[11px] font-mono tracking-widest ${
                      isActive ? 'text-amber-400' : 'text-white/30 group-hover:text-white/60'
                    }`}
                  >
                    {ch.romanNumeral}
                  </span>
                  <span className="truncate">{ch.title}</span>
                </span>
                {isActive && (
                  <ChevronRight className="w-3.5 h-3.5 text-amber-400 shrink-0 opacity-80" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Custom Layer Uploads & Actions */}
        <div className="pt-3 mt-2 border-t border-white/10 space-y-2">
          {/* Upper Image Upload / Status */}
          {hasCustomUpper ? (
            <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-amber-200 font-medium text-[11px] truncate">
                <Sparkles className="w-3.5 h-3.5 shrink-0" /> Custom Upper Active
              </span>
              <button
                onClick={onResetUpper}
                className="text-[10px] text-white/70 hover:text-white underline underline-offset-2 shrink-0 ml-1"
              >
                Reset
              </button>
            </div>
          ) : (
            <button
              onClick={() => upperFileInputRef.current?.click()}
              className="w-full flex items-center justify-center gap-2 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 border border-white/10 text-xs text-white/90 hover:text-white transition-colors"
            >
              <Upload className="w-3.5 h-3.5 text-amber-400" />
              <span>Upload Upper Image</span>
            </button>
          )}

          {/* Below Image Upload / Status */}
          {hasCustomBelow ? (
            <div className="p-2 rounded-lg bg-purple-500/10 border border-purple-500/30 text-xs flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-purple-200 font-medium text-[11px] truncate">
                <Sparkles className="w-3.5 h-3.5 shrink-0" /> Custom Below Active
              </span>
              <button
                onClick={onResetBelow}
                className="text-[10px] text-white/70 hover:text-white underline underline-offset-2 shrink-0 ml-1"
              >
                Reset
              </button>
            </div>
          ) : (
            <button
              onClick={() => belowFileInputRef.current?.click()}
              className="w-full flex items-center justify-center gap-2 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 border border-white/10 text-xs text-white/90 hover:text-white transition-colors"
            >
              <Upload className="w-3.5 h-3.5 text-purple-400" />
              <span>Upload Below Image</span>
            </button>
          )}

          {/* Legal / Brand attribution */}
          <div className="text-[11px] text-white/40 pt-1 space-y-0.5">
            <div>© Shopify Inc.</div>
            <div className="flex items-center gap-2 text-[10px] text-white/30">
              <span className="hover:text-white/60 cursor-pointer">Terms of Service</span>
              <span>·</span>
              <span className="hover:text-white/60 cursor-pointer">Privacy Policy</span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
