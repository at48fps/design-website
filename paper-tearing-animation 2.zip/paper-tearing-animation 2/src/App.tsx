import { useState, useEffect, useRef, useCallback } from 'react';
import * as THREE from 'three';
import { CHAPTERS } from './data/chapters';
import { BurnParameters, Chapter } from './types';
import { createUpperPageTexture, createBelowPageTexture } from './utils/textureGenerator';
import { PaperBurnCanvas } from './components/PaperBurnCanvas';
import { TopNav } from './components/TopNav';
import { ParameterDock } from './components/ParameterDock';
import { UploadModal } from './components/UploadModal';
import { Flame, Eye, CheckCircle2 } from 'lucide-react';

const STORAGE_KEY = 'shopify_paper_tear_custom_defaults_v2';

// Factory parameters tuned to match Screenshot_2026-11-05_at_12.06.10_PM_505555f1.png and video
const FACTORY_PARAMS: BurnParameters = {
  scrollSensitivity: 1.20,
  scrollSmoothing: 0.10,
  burnProgress: 0.35, // Show the authentic deckle tear edge on initial load
  burnWidth: 0.022, // Realistic white torn paper deckle lip
  ridgeSize: 0.012, // Very small delicate ridges matching the screenshot
  ridgeSpread: 1.5, // Natural spreadness of ridges
  surfaceScroll: 0.45, // Synchronized lower surface scrolling matching the video
  upperScroll: 0.85, // Upper artwork scrolls up with the tear, as in the video
  rashSpread: 0.03, // Fiber rashes scattered above the torn edge
  rashDensity: 0.6,
  rashInner: 0.02, // Rashes spreading inward past the white lip
  edgeVariation: 0.7, // Lip width and rashes vary randomly along the tear
  tearRoughness: 2.8, // Subtle paper pulp grain
  tearAmplitude: 0.045, // Broad organic hand-torn undulation
  charIntensity: 0.0,
  glowIntensity: 0.0,
  burnColor: '#ffffff', // Pure white paper deckle
  ashColor: '#e0ded8',
  fiberColor: '#ffffff', // Authentic bleached torn paper fibers
  colorPreset: 'custom',
  autoEdgeMovement: false, // OFF by default: paper moves ONLY when scrolling top and bottom!
  edgeMovementIntensity: 0.8,
  edgeSpeed: 0.8,
  heatDisplacement: 0.0,
  enableParticles: false,
  particleDensity: 20,
};

// Retrieve user's saved default parameters or fallback to factory settings
const getInitialParams = (): BurnParameters => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      return { ...FACTORY_PARAMS, ...parsed };
    }
  } catch (e) {
    console.warn('Could not read saved default parameters from localStorage', e);
  }
  return FACTORY_PARAMS;
};

export default function App() {
  const [chapters] = useState<Chapter[]>(CHAPTERS);
  const [activeChapterId, setActiveChapterId] = useState<string>('sidekick');
  const [customUpperImageUrl, setCustomUpperImageUrl] = useState<string | null>(null);
  const [customBelowImageUrl, setCustomBelowImageUrl] = useState<string | null>(null);

  const [parameters, setParameters] = useState<BurnParameters>(getInitialParams);
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [controlsOpen, setControlsOpen] = useState<boolean>(false);
  const [uploadModalOpen, setUploadModalOpen] = useState<boolean>(false);
  const [uploadTargetLayer, setUploadTargetLayer] = useState<'upper' | 'below'>('upper');

  // Drag and drop overlay state
  const [isWindowDragging, setIsWindowDragging] = useState<boolean>(false);
  const [dropHoverTarget, setDropHoverTarget] = useState<'upper' | 'below' | null>(null);

  // Three.js Textures
  const [upperTexture, setUpperTexture] = useState<THREE.CanvasTexture | null>(null);
  const [belowTexture, setBelowTexture] = useState<THREE.CanvasTexture | null>(null);

  const activeChapter = chapters.find((c) => c.id === activeChapterId) || chapters[0];

  // Generate / update Upper Texture
  useEffect(() => {
    let isCurrent = true;
    createUpperPageTexture({
      chapter: activeChapter,
      customImageUrl: customUpperImageUrl,
    }).then((tex) => {
      if (isCurrent) {
        setUpperTexture((prev) => {
          prev?.dispose();
          return tex;
        });
      }
    });

    return () => {
      isCurrent = false;
    };
  }, [activeChapter, customUpperImageUrl]);

  // Generate / update Below Texture
  useEffect(() => {
    let isCurrent = true;
    createBelowPageTexture({
      customImageUrl: customBelowImageUrl,
      defaultDashboardUrl: '/src/assets/images/sidekick_pulse_dashboard_1793789347093.jpg',
    }).then((tex) => {
      if (isCurrent) {
        setBelowTexture((prev) => {
          prev?.dispose();
          return tex;
        });
      }
    });

    return () => {
      isCurrent = false;
    };
  }, [customBelowImageUrl]);

  // Direct file loader
  const handleDirectFile = useCallback((file: File, layer: 'upper' | 'below') => {
    const isImage =
      file.type.startsWith('image/') ||
      /\.(jpe?g|png|webp|gif|svg|avif|bmp)$/i.test(file.name);
    if (!isImage) {
      alert('Please select an image file (PNG, JPG, WEBP, or SVG).');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        if (layer === 'upper') {
          setCustomUpperImageUrl(result);
        } else {
          setCustomBelowImageUrl(result);
          setParameters((prev) => ({
            ...prev,
            burnProgress: prev.burnProgress < 0.15 ? 0.45 : prev.burnProgress,
          }));
        }
      }
    };
    reader.readAsDataURL(file);
  }, []);

  // Global window drag and drop
  useEffect(() => {
    const handleDragOver = (e: DragEvent) => {
      e.preventDefault();
      if (e.dataTransfer?.types.includes('Files')) {
        setIsWindowDragging(true);
      }
    };

    const handleDragLeave = (e: DragEvent) => {
      if (
        e.clientX <= 0 ||
        e.clientY <= 0 ||
        e.clientX >= window.innerWidth ||
        e.clientY >= window.innerHeight
      ) {
        setIsWindowDragging(false);
      }
    };

    const handleDrop = (e: DragEvent) => {
      e.preventDefault();
      setIsWindowDragging(false);
    };

    window.addEventListener('dragover', handleDragOver);
    window.addEventListener('dragleave', handleDragLeave);
    window.addEventListener('drop', handleDrop);

    return () => {
      window.removeEventListener('dragover', handleDragOver);
      window.removeEventListener('dragleave', handleDragLeave);
      window.removeEventListener('drop', handleDrop);
    };
  }, []);

  // Parameter change handler
  const handleParamChange = useCallback((newParams: Partial<BurnParameters>) => {
    setParameters((prev) => ({ ...prev, ...newParams }));
  }, []);

  // Save current parameters as user's permanent default
  const handleSaveAsDefault = useCallback(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(parameters));
      setIsSaved(true);
      setToastMessage('Parameters saved! These will now load as your default.');
      setTimeout(() => setIsSaved(false), 2500);
      setTimeout(() => setToastMessage(null), 3500);
    } catch (e) {
      console.error('Failed to save default parameters to localStorage', e);
      alert('Could not save defaults to browser storage.');
    }
  }, [parameters]);

  // Reset to saved default parameters
  const handleResetParams = useCallback(() => {
    const defaultParams = getInitialParams();
    setParameters({
      ...defaultParams,
      burnProgress: parameters.burnProgress,
    });
    setToastMessage('Reset parameters to your saved default settings.');
    setTimeout(() => setToastMessage(null), 3000);
  }, [parameters.burnProgress]);

  // Progress change from canvas wheel/touch
  const handleProgressChange = useCallback((newProgress: number) => {
    setParameters((prev) => ({ ...prev, burnProgress: newProgress }));
  }, []);

  const handleOpenUpload = (target: 'upper' | 'below') => {
    setUploadTargetLayer(target);
    setUploadModalOpen(true);
  };

  const handleImageUploaded = (dataUrl: string) => {
    if (uploadTargetLayer === 'upper') {
      setCustomUpperImageUrl(dataUrl);
    } else {
      setCustomBelowImageUrl(dataUrl);
      if (parameters.burnProgress < 0.15) {
        setParameters((prev) => ({ ...prev, burnProgress: 0.45 }));
      }
    }
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#101014] text-white font-ui select-none">
      {/* Top Navigation Bar - Clean, with prominent Save as Default and Parameters toggle */}
      <TopNav
        onToggleControls={() => setControlsOpen((prev) => !prev)}
        controlsOpen={controlsOpen}
        onResetProgress={() => {
          setParameters((prev) => ({ ...prev, burnProgress: 0 }));
        }}
        onSaveAsDefault={handleSaveAsDefault}
        isSaved={isSaved}
      />

      {/* Main WebGL Paper Tear Canvas - Left side is completely unobstructed with ZERO text */}
      <PaperBurnCanvas
        upperTexture={upperTexture}
        belowTexture={belowTexture}
        parameters={parameters}
        onProgressChange={handleProgressChange}
      />

      {/* Collapsible Bottom Parameter & Chapter Dock */}
      <ParameterDock
        parameters={parameters}
        onChange={handleParamChange}
        onReset={handleResetParams}
        onSaveAsDefault={handleSaveAsDefault}
        isSaved={isSaved}
        chapters={chapters}
        activeChapterId={activeChapterId}
        onSelectChapter={(id) => {
          setActiveChapterId(id);
          setCustomUpperImageUrl(null);
        }}
        onUploadUpperDirect={(file) => handleDirectFile(file, 'upper')}
        onUploadBelowDirect={(file) => handleDirectFile(file, 'below')}
        hasCustomUpper={!!customUpperImageUrl}
        hasCustomBelow={!!customBelowImageUrl}
        onResetUpper={() => setCustomUpperImageUrl(null)}
        onResetBelow={() => setCustomBelowImageUrl(null)}
        isOpen={controlsOpen}
        onToggleOpen={() => setControlsOpen((prev) => !prev)}
      />

      {/* Floating Save Confirmation Toast */}
      {toastMessage && (
        <div className="fixed top-18 right-6 z-50 flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-neutral-900/95 border border-white/20 text-xs text-white shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-top-2 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Full-screen Drag and Drop Overlay for Instant File Dropping */}
      {isWindowDragging && (
        <div className="fixed inset-0 z-50 flex flex-col md:flex-row bg-black/85 backdrop-blur-md p-6 gap-6 animate-in fade-in duration-200">
          {/* Drop Target: Upper Layer */}
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDropHoverTarget('upper');
            }}
            onDragLeave={() => setDropHoverTarget(null)}
            onDrop={(e) => {
              e.preventDefault();
              setIsWindowDragging(false);
              setDropHoverTarget(null);
              if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                handleDirectFile(e.dataTransfer.files[0], 'upper');
              }
            }}
            className={`flex-1 rounded-2xl border-4 border-dashed flex flex-col items-center justify-center p-8 transition-all ${
              dropHoverTarget === 'upper'
                ? 'border-amber-400 bg-amber-500/20 scale-[1.01]'
                : 'border-white/30 bg-white/5'
            }`}
          >
            <div className="w-16 h-16 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 mb-4">
              <Flame className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-white mb-1">
              Drop here for UPPER LAYER
            </h3>
            <p className="text-sm text-white/60 text-center max-w-sm">
              Replaces the top image that tears away when scrolling.
            </p>
          </div>

          {/* Drop Target: Below Revealed Layer */}
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDropHoverTarget('below');
            }}
            onDragLeave={() => setDropHoverTarget(null)}
            onDrop={(e) => {
              e.preventDefault();
              setIsWindowDragging(false);
              setDropHoverTarget(null);
              if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                handleDirectFile(e.dataTransfer.files[0], 'below');
              }
            }}
            className={`flex-1 rounded-2xl border-4 border-dashed flex flex-col items-center justify-center p-8 transition-all ${
              dropHoverTarget === 'below'
                ? 'border-purple-400 bg-purple-500/20 scale-[1.01]'
                : 'border-white/30 bg-white/5'
            }`}
          >
            <div className="w-16 h-16 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-400 mb-4">
              <Eye className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-white mb-1">
              Drop here for BELOW LAYER
            </h3>
            <p className="text-sm text-white/60 text-center max-w-sm">
              Replaces the lower image revealed underneath the torn edge.
            </p>
          </div>
        </div>
      )}

      {/* Image Upload Modal */}
      <UploadModal
        isOpen={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        targetLayer={uploadTargetLayer}
        onImageSelected={handleImageUploaded}
      />
    </div>
  );
}
